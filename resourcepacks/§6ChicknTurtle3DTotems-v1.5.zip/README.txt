
	ChicknTurtle's 3D Totems
https://modrinth.com/resourcepack/chicknturtles-3d-totems
https://curseforge.com/minecraft/texture-packs/chicknturtles-3d-totems

Created by ChicknTurtle:
 https://modrinth.com/user/ChicknTurtle
 https://curseforge.com/members/ChicknTurtle
